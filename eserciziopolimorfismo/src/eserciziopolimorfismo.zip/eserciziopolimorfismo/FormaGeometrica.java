package eserciziopolimorfismo;

public interface FormaGeometrica {
	
	// Metodi
	double calcolaArea();
	
	double calcolaPerimetro();
	
}
